import cv2
import mediapipe as mp
import numpy as np
from tensorflow.keras.models import load_model
from collections import deque

# Load the trained gesture recognition model
model = load_model('model_copy.keras')

# Define the gestures
gestures = {
    0: 'Fist',               
    1: 'One',                
    2: 'Two',                
    3: 'Three',              
    4: 'Four',               
    5: 'Five',               
    6: 'Six',        
    7: 'Seven',     
    8: 'Eight',     
    9: 'Nine',      
    10: 'Ten',       
    11: 'Me',       
    12: 'I',        
    13: 'You',      
    14: 'We',       
    15: 'Hello',       
    16: "What's up?",  
    17: 'Hi',    
    18: 'Hey',      
    19: 'Yes',      
    20: 'No',       
    21: 'Thank you!',  
    22: 'Goodbye',  
    23: 'Please',   
    24: 'Sorry',    
    25: 'Help',     
    26: 'Stop',     
    27: 'I love you'    
}

# Instructions for the gestures
instructions = {
    'Fist': 'Make a closed fist with your hand.',
    'One': 'Hold up one finger.',
    'Two': 'Hold up two fingers.',
    'Three': 'Hold up three fingers.',
    'Four': 'Hold up four fingers.',
    'Five': 'Hold up five fingers.',
    'Six': 'Thumb touches pinky.',
    'Seven': 'Thumb touches ring finger.',
    'Eight': 'Thumb touches middle finger.',
    'Nine': 'Thumb touches index finger.',
    'Ten': 'Give a thumbs up and shake.',
    'Me': 'Point to yourself with your index finger.',
    'I': 'Point directly to your chest.',
    'You': 'Point outward with your index finger.',
    'We': 'Circular motion starting from yourself outward.',
    'Hi': 'Wave your hand vertically.',
    'What\'s up?': 'Flick your middle finger from chest outward.',
    'Hello': 'Salute with your right hand.',
    'Hey': 'Wave hand sideways.',
    'Yes': 'Nod fist as if saying yes.',
    'No': 'Shake your index and middle finger.',
    'Thank you!': 'Move fingers forward from your chin.',
    'Goodbye': 'Wave hand sideways.',
    'Please': 'Rub open hand in a circular motion on your chest.',
    'Sorry': 'Rub closed fist in a circular motion on your chest.',
    'Help': 'Place thumb-up hand on other open palm.',
    'Stop': 'Chop right hand onto left hand.',
    'I love you': 'Middle and ring fingers down.'
}

# List of words to learn and their instructions
words_to_learn = list(gestures.values())
learned_words = []

# Confidence threshold (adjustable)
confidence_threshold = 0.6

# Initialize MediaPipe Hands for hand landmark detection
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.5, min_tracking_confidence=0.5)
mp_draw = mp.solutions.drawing_utils

# Initialize webcam
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open camera.")
    exit()

# Initialize deque to store recent predictions
gesture_queue = deque(maxlen=10)

# Track how many times each gesture has been correctly predicted
gesture_correct_count = {gesture: 0 for gesture in gestures.values()}
max_correct = 10  # Number of times the gesture needs to be detected before it is "learned"

# Initialize progress bar tracking
rounds_completed = 0
total_rounds = 10  # Number of rounds to complete
bar_height = 300  # Height of the vertical progress bar

# Only allow learning gestures in order
current_learning_index = 0

# Function to reset the practice
def reset_practice():
    global learned_words, current_learning_index, gesture_correct_count, rounds_completed
    
    # Check if all words have been learned
    if current_learning_index >= len(words_to_learn):
        print("Congratulations! All gestures learned.")
        rounds_completed += 1  # Increment rounds if a round was completed
        if rounds_completed > total_rounds:
            rounds_completed = total_rounds  # Cap the number of rounds
    
    # Reset the practice session
    learned_words = []
    current_learning_index = 0
    gesture_correct_count = {gesture: 0 for gesture in gestures.values()}
    print("Practice has been reset.")

# Function to draw the vertical progress bar with a gradient and center it between titles
def draw_vertical_progress_bar(frame, rounds_completed, total_rounds, bar_height):
    # Calculate the progress percentage
    progress = rounds_completed / total_rounds

    # Define the position and dimensions of the progress bar
    # Calculate the center position between "Words to Learn" and "Learned Words"
    words_to_learn_x = frame_width - 500
    learned_words_x = frame_width - 500
    bar_x = (words_to_learn_x + learned_words_x) - 1000  # Center position between titles
    bar_y = 100  # Starting position for the bar
    bar_width = 30

    # Draw the background of the progress bar (gray)
    cv2.rectangle(frame, (bar_x, bar_y), (bar_x + bar_width, bar_y + bar_height), (192, 192, 192), -1)

    # Calculate the filled height based on the progress
    filled_height = int(bar_height * progress)

    # Draw the filled portion of the progress bar with gradient
    for i in range(filled_height):
        ratio = i / bar_height
        # Interpolate colors between red, yellow, and green
        if ratio <= 0.5:
            # Red to Yellow gradient
            color = (0, int(255 * (ratio * 2)), 255)
        else:
            # Yellow to Green gradient
            color = (0, 255, int(255 * (2 - ratio * 2)))

        cv2.line(frame, (bar_x, bar_y + bar_height - i), (bar_x + bar_width, bar_y + bar_height - i), color, 1)

    # Display the progress in text format, centered below the progress bar
    cv2.putText(frame, f'{rounds_completed}/{total_rounds}', (bar_x - 20, bar_y + bar_height + 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

# Process frames from the webcam
while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Flip the frame horizontally (to correct mirrored camera feed)
    frame = cv2.flip(frame, 1)
    frame_height, frame_width, _ = frame.shape

    # Convert the frame to RGB (required by MediaPipe)
    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    image.flags.writeable = False
    results = hands.process(image)
    image.flags.writeable = True

    # If hand landmarks are detected
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            # Extract hand landmarks for the detected hand(s)
            landmark_list = []
            for lm in hand_landmarks.landmark:
                landmark_list.extend([lm.x, lm.y, lm.z])

            # Convert the landmarks to a NumPy array and reshape it for the model
            landmarks_np = np.array(landmark_list).reshape(1, 1, -1)

            # Make prediction
            prediction = model.predict(landmarks_np)
            predicted_class = np.argmax(prediction)
            confidence = np.max(prediction)

            # Only add to gesture queue if confidence is above threshold
            if confidence >= confidence_threshold:
                predicted_gesture = gestures[predicted_class]
                gesture_queue.append(predicted_gesture)

            # Display the most frequent gesture in the deque (to smooth out predictions)
            if gesture_queue:
                most_frequent_gesture = max(set(gesture_queue), key=gesture_queue.count)

                # Check if current_learning_index is valid
                if current_learning_index < len(words_to_learn):
                    # Increment correct count if the gesture is detected correctly and matches the current learning gesture
                    if most_frequent_gesture == words_to_learn[current_learning_index]:
                        gesture_correct_count[most_frequent_gesture] += 1
                    
                    # Move to "Learned Words" if detected correctly enough times and in order
                    if gesture_correct_count[most_frequent_gesture] >= max_correct and most_frequent_gesture == words_to_learn[current_learning_index]:
                        learned_words.append(most_frequent_gesture)
                        current_learning_index += 1  # Move to the next word in order
                else:
                    # Display congratulations message if all words are learned
                    cv2.putText(frame, 'All words learned! Press "r" to reset.', (10, 60),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

                # Display the gesture prediction
                cv2.putText(frame, f'Gesture: {most_frequent_gesture} ({confidence:.2f})', (10, 30), 
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    else:
        cv2.putText(frame, 'No hand detected', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    # Display "Words to Learn" and "Learned Words"
    cv2.putText(frame, 'Words to Learn:', (frame_width - 500, 30), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 255), 3)
    
    # Highlight the current gesture being learned in white
    for idx, word in enumerate(words_to_learn[current_learning_index:current_learning_index+5]):  # Show 5 words at a time
        color = (255, 255, 255) if idx == 0 else (192, 192, 192)
        cv2.putText(frame, f'{word}: {instructions[word]}', (frame_width - 500, 60 + idx * 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        

    # Display "Learned Words" starting at the same height but positioned higher and with adjusted word placement
    cv2.putText(frame, 'Learned Words:', (frame_width - 500, frame_height - 300),  # Moved higher
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 3)

    # Set maximum words per column based on space available
    max_words_per_column = 9  # Adjust if needed based on your layout
    column_width = 150  # Distance between columns

    # Display the learned words in multiple columns if necessary
    for idx, word in enumerate(learned_words):
        # Determine which column and row to place the word in
        col = idx // max_words_per_column  # Calculate column number
        row = idx % max_words_per_column   # Calculate row number

        # Adjust x position based on the column
        x_position = frame_width - (600 - col * column_width)
        y_position = frame_height - 270 + row * 30  # Adjusted position to move learned words higher

        # Display the word in the correct column and row
        cv2.putText(frame, word, (x_position, y_position), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    # Draw the vertical progress bar
    draw_vertical_progress_bar(frame, rounds_completed, total_rounds, bar_height)

    # Show the frame
    cv2.imshow('Gesture Prediction', frame)

    # Press 'q' to quit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
# Release resources
cap.release()
cv2.destroyAllWindows()
